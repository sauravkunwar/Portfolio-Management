from django.apps import AppConfig


class UserRegistrationConfig(AppConfig):
    name = 'user_registration'
